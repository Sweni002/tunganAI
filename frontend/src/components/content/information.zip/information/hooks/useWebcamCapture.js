// hooks/useWebcamCapture.js
import { useEffect, useRef, useState } from 'react';
import * as faceapi from 'face-api.js';
import { dataURLtoFile } from '../utils/fileHelpers';

/**
 * @param {boolean} modelsLoaded
 * @param {(payload: { imageSrc: string, imageFile: File, faceDescriptor: number[] }) => void} onCaptureSuccess
 * @param {(message: string) => void} onNoFaceDetected
 */
export function useWebcamCapture({ modelsLoaded, onCaptureSuccess, onNoFaceDetected }) {
  const webcamRef = useRef(null);
  const canvasRef = useRef(null);

  const [openWeb, setOpenWeb] = useState(false);
  const [webcamLoading, setWebcamLoading] = useState(false);
  const [capturing, setCapturing] = useState(false);
  const [webcamReady, setWebcamReady] = useState(false);
  const [scanning, setScanning] = useState(false);

  // Détecte quand le flux vidéo de la webcam est réellement prêt
  useEffect(() => {
    const checkVideo = setInterval(() => {
      const video = webcamRef.current?.video;
      if (video && video.readyState === 4) {
        setWebcamReady(true);
        clearInterval(checkVideo);
      }
    }, 100);
    return () => clearInterval(checkVideo);
  }, [webcamRef]);

  // Dessine en continu les rectangles de détection de visage sur le canvas overlay
  useEffect(() => {
    if (!modelsLoaded) return;

    const interval = setInterval(async () => {
      if (webcamRef.current && webcamRef.current.video.readyState === 4) {
        const video = webcamRef.current.video;
        const canvas = canvasRef.current;
        const context = canvas.getContext('2d');
        context.clearRect(0, 0, canvas.width, canvas.height);

        const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions());
        const displaySize = { width: video.videoWidth, height: video.videoHeight };
        faceapi.matchDimensions(canvas, displaySize);
        const resizedDetections = faceapi.resizeResults(detections, displaySize);

        resizedDetections.forEach((detection) => {
          const box = detection.box;
          context.strokeStyle = 'white';
          context.lineWidth = 1;
          context.strokeRect(box.x, box.y, box.width, box.height);
        });
      }
    }, 100);

    return () => clearInterval(interval);
  }, [modelsLoaded, scanning]);

  const handleCapture = async () => {
    if (!webcamRef.current) return;
    setCapturing(true);

    const video = webcamRef.current.video;
    if (video.readyState !== 4) {
      setCapturing(false);
      return;
    }
    setWebcamLoading(true);

    const detection = await faceapi
      .detectSingleFace(video, new faceapi.TinyFaceDetectorOptions())
      .withFaceLandmarks()
      .withFaceDescriptor();

    if (!detection) {
      onNoFaceDetected?.('Aucun visage détecté.');
      setWebcamLoading(false);
      setCapturing(false);
      return;
    }

    const imageSrc = webcamRef.current.getScreenshot();
    const imageFile = dataURLtoFile(imageSrc, 'webcam.jpg');
    const faceDescriptor = Array.from(detection.descriptor);

    onCaptureSuccess?.({ imageSrc, imageFile, faceDescriptor });

    setWebcamLoading(false);
    setOpenWeb(false);
    setCapturing(false);
  };

  return {
    webcamRef,
    canvasRef,
    openWeb,
    setOpenWeb,
    webcamLoading,
    capturing,
    webcamReady,
    scanning,
    setScanning,
    handleCapture,
  };
}
